package eth.utils;

import java.io.IOException;
import java.io.InputStream;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.tomcat.util.digester.SetPropertiesRule;
import org.eclipse.jdt.internal.compiler.ast.ThisReference;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Driver;
import com.mysql.jdbc.Statement;

public class ConnectDatabase {
    
	   


    	
    	
	    private static String URL ="";
	    private static String USER ="";
	    private static String PASSWORD ="";
       
	    
	        public static void  SetPropertiesRule(String url,String user,String password){
	        	URL=url;
	        	USER=user;
	        	PASSWORD=password;
	        	
	        }
	    
	    static {
	        try {
	            Class.forName("com.mysql.jdbc.Driver");
	        } catch (ClassNotFoundException e) {
	            System.out.println("加载Mysql数据库驱动失败！");
	        }
	    }
	     
//	    public static void setproperties() throws IOException{
//	    	
//	        ins = Object.class.getClass().getResourceAsStream(path);
//	        
//	        properties.load(ins);
//	        URL= properties.getProperty( "url" ).trim();    
//            USER=properties.getProperty( "username" ).trim();    
//            PASSWORD=properties.getProperty( "password" ).trim();
//	         
//            System.out.println(URL);
//            
//            
//            System.out.println("赋值");
//          
//	    }
	    
	    
	    /**
	     * 获取Connection
	     * 
	     * @return
	     * @throws SQLException
	     * @throws IOException 
	     * @throws ClassNotFoundException
	     */
	    public static Connection getConnection() throws SQLException, IOException {
	        Connection conn = null;
	   
	        try { 
	        	
	            conn = (Connection) DriverManager.getConnection(URL, USER, PASSWORD);
	            //获取数据库连接成功
	            System.out.println("连接成功！");
	        } catch (SQLException e) {
	            System.out.println("获取数据库连接失败！");
	            throw e;
	        }
	        return conn;
	    }
	    
	    
	    
	     
	
	
	
}
	


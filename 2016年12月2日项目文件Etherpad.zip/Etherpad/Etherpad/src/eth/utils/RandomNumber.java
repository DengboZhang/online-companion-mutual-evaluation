package eth.utils;

import java.util.Random;


public class RandomNumber {
     
	//创建一个随机对象
	private static Random random=new Random();
	
	
	
	/**
	 * 随机生成一个颜色的数值
	 */
	public  static  int getRandomNumber(){
		 
		int i=random.nextInt(256);
		return i;
			      
	}
	
}

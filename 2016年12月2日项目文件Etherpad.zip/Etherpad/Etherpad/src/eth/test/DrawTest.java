package eth.test;

import org.junit.Test;

import eth.utils.RandomNumber;

/**
 * 产生雷达图阶段的所有单元测试
 * @author Administrator
 *
 */
public class DrawTest {
    
	//产生一个随机数字
	@Test
	public void demo1(){
		int i;
		
		for(int j=0;j<10000;j++){
			i=RandomNumber.getRandomNumber();
			if(i==0)
			System.out.println("产生的随机数字是： "+i);
		}
		
		
	}//测试完毕 每次产生结果   在   0-255 之间的int类型的整数
	
	
	
}

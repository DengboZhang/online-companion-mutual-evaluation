package eth.test;

import java.io.IOException;
import java.sql.SQLException;

import org.junit.Test;

import com.mysql.jdbc.Connection;

import eth.utils.ConnectDatabase;

public class ConnectTest {
	
	@Test
	public void test1() throws SQLException, IOException{
		
		Connection conn=ConnectDatabase.getConnection();
		
	}

}

package eth.servlet;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;

import eth.bean.User;
import eth.utils.ConnectDatabase;

/**
 * Servlet implementation class Deallogin
 */
@WebServlet("/Deallogin")
public class Deallogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
	

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Deallogin() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		/**
		 * 
		 * 写判断逻辑
		 * 
		 * 
		 * 
		 */
		System.out.println("\n");
		System.out.println("*********************Start Deallogin servlet*********************");
		User user=new User();
         
		String url;
		String dbname;
		String dbpassword;
		    ServletContext sc=getServletContext();  
	        String path=sc.getRealPath("/WEB-INF/Infodata.properties");  
	        Properties props=new Properties();//读取文件类型创建对象。  
	        props.load(new FileInputStream(path));  
	        String hostinfo=props.getProperty("hostinfo");  
	        String apikey=props.getProperty("apikey");
	        dbname=props.getProperty("username");
	        url=props.getProperty("url");
	        dbpassword=props.getProperty("password");
	        ConnectDatabase.SetPropertiesRule(url, dbname, dbpassword);
		
		Connection conn =null;//连接数据库
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		
		
		
		
		String authorID;
		String groupID;
		String padName;
		
		
		
		
		

		request.setCharacterEncoding("utf-8");	
		response.setCharacterEncoding("gb2312");
		
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		
		

		try {
            
			
			
			
			conn=ConnectDatabase.getConnection();
			String strsql1 = "select *from user where username=? and password=?";
		    pstmt = (PreparedStatement) conn.prepareStatement(strsql1);
			pstmt.setString(1, username);
			pstmt.setString(2, password);
			rs = pstmt.executeQuery();
            
			
			if (rs.next()) {

				// 登录成功,就将登录表单的信息封装为一个User的实例对象发送到服务端
				user.setUsername(username);
	            user.setPassword(password);
	          
	            groupID=rs.getString(6);
	            authorID=rs.getString(5);
	            padName=rs.getString(7);
	            
	            //分组，创建pad 分配用户
	            
                
	            System.out.println(authorID);
	            System.out.println(user);
	            System.out.println(groupID);
	            System.out.println(padName);
	            
				request.getSession().setAttribute("user", user);// 封装信息的javabean对象，将信息传送到.jsp中
				request.getSession().setAttribute("authorID",authorID);
				request.getSession().setAttribute("groupID",groupID);
				request.getSession().setAttribute("padName",padName);
				request.getSession().setAttribute("username", username);
				
				
				
				response.setHeader("Refresh", "1;URL=loginsuccess.jsp");
				response.getWriter().write("登录成功！正在为配置您的etherpad！请稍等！");
				
				
				
				

			} else {
				
				response.setHeader("Refresh", "2;URL=login.jsp");
				response.getWriter().write("对不起！您的用户名或者密码 为空 或者 错误！登录失败！2秒后自动跳转到登录页面！");

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
	       request.getSession().setAttribute("hostinfo",hostinfo);
	       request.getSession().setAttribute("apikey",apikey);
		   
	       
		System.out.println("*********************End Deallogin servlet*********************");
		
        
	}
  
	
	
}

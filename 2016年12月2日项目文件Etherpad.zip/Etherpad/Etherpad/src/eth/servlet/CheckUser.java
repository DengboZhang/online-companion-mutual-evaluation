package eth.servlet;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.coyote.http11.filters.VoidInputFilter;
import org.json.simple.JSONObject;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

import eth.bean.Group;
import eth.bean.User;
import eth.utils.ConnectDatabase;

/**
 * Servlet implementation class DealRegister
 */
@WebServlet("/DealRegister")
public class CheckUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CheckUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		request.setCharacterEncoding("utf-8");	
		response.setCharacterEncoding("gb2312");
		
		
		System.out.println("\n");
		System.out.println("*********************Start DealRegister servlet*********************");
		int  mapper=0;
		
		String data="00";
		String data1="0";
		String data2="0";
		String url;
		String dbname;
		String dbpassword;
		    ServletContext sc=getServletContext();  
	        String path=sc.getRealPath("/WEB-INF/Infodata.properties");  
	        Properties props=new Properties();//读取文件类型创建对象。  
	        props.load(new FileInputStream(path));  
	        String hostinfo=props.getProperty("hostinfo");  
	        String apikey=props.getProperty("apikey");
	        dbname=props.getProperty("username");
	        url=props.getProperty("url");
	        dbpassword=props.getProperty("password");
	        ConnectDatabase.SetPropertiesRule(url, dbname, dbpassword);
	        
	        
	        System.out.println(hostinfo);//结果：
	        System.out.println(apikey);
		Connection conn = null;//连接数据库
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		boolean result=true;
		
		
		User user=new User();//封装对象
		Group group=new Group();//将要被填充到user里
		
		
		
		
		
		
	    try {
	    	
	    	conn=ConnectDatabase.getConnection();
	    	String sql2="select max(usermapper) from user";
			
	    	
			pstmt=(PreparedStatement) conn.prepareStatement(sql2);
			
		    rs= pstmt.executeQuery();
			
			
			
			rs.next();
			
		
			mapper=rs.getInt(1)+1;
			System.out.println(mapper);
			
		} catch (SQLException e1) {
			
			System.out.println("exception");
			e1.printStackTrace();
		}
	    
		
		
		
		
		
		
		
		//填充模型
//	    group.setGroupID(request.getParameter("groupID"));
	    group.setGroupNumber(request.getParameter("groupid"));//mapper,组号
	    
		user.setUsername(request.getParameter("username"));
		user.setPassword(request.getParameter("password"));
//        user.setAuthorID(request.getParameter("authorid"));
       /* user.setGroup(group);*/
	    user.setMapper(mapper);
	    String padName="pad"+group.getGroupNumber();
	   
	    request.getSession().setAttribute("user",user);
	    request.getSession().setAttribute("group",group);
	   
	
		//第一步将数据插入到本地数据库
		
		
	    //执行插入语句
	   
	    //第一步判断用户是否已经存在
	
	    
	    String sqlcheckuser = "select * from user where username='"+user.getUsername()+"'";
	    try {
			 pstmt= (PreparedStatement)conn.prepareStatement(sqlcheckuser);
			 rs = pstmt.executeQuery();
			 result=rs.next();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	   
	    //判断用户和小组是否是新的  用 00 来表示两个结果，00新的用户新的小组，01新用户，老小组  开头是1~直接不作处理
	    
	    
        try{
        	
        	 
        	  
	    if(result){
	      
	    	data1="1";
	    	System.out.println("该用户已经存在！");
	    }
	    else{
	    	
	    	data1="0";
	    	String sqlcheckgroup="select * from usergroup where groupnum='"+group.getGroupNumber()+"'";
	    	pstmt=(PreparedStatement) conn.clientPrepareStatement(sqlcheckgroup);
	    	rs=pstmt.executeQuery();
	    	
	    	if(rs.next()){
	    		System.out.println("该小组已经存在！");
	    		data2="1";
	    	}else{
	    	  System.out.println("该小组不存在！");
	    	  data2="0";
	    	}
	    	
	    }
	    	data=data1+data2;
	    	
	    	
	    	
	    	
	    
        }catch (Exception e) {
			System.out.println("在判断用户名是否重复时报了异常！");
		}
        
        System.out.println(data);
        
        //尝试获取资源文件，并且读取到属性，发送给前台
      
        
        
        StringBuilder jsondata = new StringBuilder();  
  	    System.out.println("数据库没有用户");
  	    jsondata.append("{").append("\"data\":\"").append(data).append("\"").append(",").append("\"authorMapper\":\"").append(mapper).append("\"").append(",").append("\"padName\":\"").append(padName).append("\"").append(",").append("\"hostinfo\":\"").append(hostinfo).append("\"").append(",").append("\"apikey\":\"").append(apikey).append("\"").append("}"); //构建json串
   	    System.out.println(jsondata);
  	    response.setContentType("text/javascript");  //声明类型防止乱码
   		try {
   			response.getWriter().print(jsondata.toString());
   		} catch (IOException e) {
   			// TODO Auto-generated catch block
   			e.printStackTrace();
   		} //响应JSON
        
   		
			
		
   		System.out.println("*********************End Dealregister servlet*********************");
	    
   		
		
 
         
         
   		
   		
   		
   		
	    

} 
					    	  
					    	   
					    	  
					     
			      
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	
	
}

package eth.servlet;

import java.io.IOException;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.StreamingNotifiable;

import eth.utils.ConnectDatabase;

/**
 * Servlet implementation class SaveData
 */
@WebServlet("/SaveData")
public class SaveData extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SaveData() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");	
		response.setCharacterEncoding("gb2312");
		System.out.println("\n");
		System.out.println("*********************Start SaveData servlet*********************");
		//1 设置接收data的属性
		String  commentid;//评论在服务器上的id
		String  type;//评论属于哪一类
		String  score;//评论的分数
		String  timestamp;//时间戳
		String  commenterId;//创建评论的人
		String  authorId;//被评论而且要给出评论分数的人
	
		
	
		
		//2 接收给属性赋值
		commentid=request.getParameter("commentId");
		System.out.println("commentid="+commentid);
		
		type=request.getParameter("radioValue");
		System.out.println("type="+type);
		
		score=request.getParameter("replayStar");
		System.out.println("score="+score);
		
		timestamp=request.getParameter("timestamp");
		System.out.println("commentid="+commentid);
		
		commenterId=request.getParameter("AuthorID");
		System.out.println("commenterId="+commenterId);
		
		authorId=request.getParameter("Commenter");
		System.out.println("authorId="+authorId);
		
		
		//3 获得与数据库的连接项
		Connection conn = null;//连接数据库
		PreparedStatement pstmt=null;
		
		
		
		
		
		//4 向数据库插入数据
		  try {
		    	
			    //插入comments语句
		    	String sql="insert into comments (commentId,type,score,timestamp,commenterId,authorId) values(?,?,?,?,?,?)";
		 	    //获得与数据库的连接
		    	conn=ConnectDatabase.getConnection();
		        pstmt = (PreparedStatement) conn.prepareStatement(sql);
	            pstmt.setString(1,commentid);
	            pstmt.setString(2,type);
		        pstmt.setString(3,score);
		        pstmt.setString(4,timestamp);
		        pstmt.setString(5,commenterId);
		        pstmt.setString(6,authorId);
		       
		        
		        pstmt.executeUpdate();//执行语句update
		        
		       
		        //插入成功
		  }catch (Exception e) {
		         System.out.println("向数据库插入comments发生异常！");
		  }
		
		
		    
		
		
		
	     System.out.println("*********************End SaveData servlet*********************");   
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

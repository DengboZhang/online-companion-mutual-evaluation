package eth.servlet;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

import eth.bean.Group;
import eth.bean.Pad;
import eth.bean.User;
import eth.utils.ConnectDatabase;

/**
 * Servlet implementation class SaveID
 */
@WebServlet("/SaveID")
public class CreateUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CreateUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("\n");
		System.out.println("*********************Start SaveID servlet*********************");
		
		User user=new User();//封装对象
		Group group=new Group();//将要被填充到user里
		Pad pad=new Pad();
		Connection conn = null;//连接数据库
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		 
		
	 	user=(User) request.getSession().getAttribute("user");
        group=(Group) request.getSession().getAttribute("group");
        
	      group.setGroupID(request.getParameter("groupID"));
		  group.setGroupNumber(request.getParameter("groupid"));    
		       
		      
		      if(group.getGroupID().equals("")){
		    	  
			       
			        try {
			        	conn=ConnectDatabase.getConnection();
			        	String sql6="select * from usergroup where groupnum='"+group.getGroupNumber()+"'";
						pstmt=(PreparedStatement) conn.prepareStatement(sql6);
					    rs=pstmt.executeQuery(); 
					    rs.next();
					    group.setGroupID(rs.getString(2));
					    System.out.println("111111111111111111111111111");
					    
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						System.out.println("查询小组组号时出了异常！");
						e.printStackTrace();
					}	  
			       
		      }
		      
		      
		      
		      
		   	  user.setAuthorID(request.getParameter("authorID"));
		   	  group.setGroupname("小组"+group.getGroupNumber());
		   	  pad.setPadName("pad"+group.getGroupNumber());
		   	  pad.setPadID(group.getGroupID()+"$"+pad.getPadName());
		   	  user.setGroup(group);//到此为止模型填充完毕
		      group.setPad(pad);
		      
		   	    System.out.println(user);
				System.out.println(group);
				System.out.println(pad);
				
				
				
				
				
				
				
		         try {
			    	
			    	String sql="insert into user (username,password,groupnumber,authorid,usermapper,usergroupid,usergrouppadname) values(?,?,?,?,?,?,?)";
			 	    
			    	conn=ConnectDatabase.getConnection();
			        pstmt = (PreparedStatement) conn.prepareStatement(sql);
		            pstmt.setString(1, user.getUsername());
		            pstmt.setString(2, user.getPassword());
			        pstmt.setString(3, user.getGroup().getGroupNumber());//group的mapper
			        pstmt.setString(4, user.getAuthorID());
			        pstmt.setInt(5,user.getMapper());
			        pstmt.setString(6,user.getGroup().getGroupID());
			        pstmt.setString(7,user.getGroup().getPad().getPadName());
			        
			        pstmt.executeUpdate();//执行语句update
			        
			       
			        //插入成功
			        
			        
			        
			      //第二步，判断有没有这个组
			        
			        String sql3="select * from usergroup where groupnum='"+group.getGroupNumber()+"'";
			        pstmt=(PreparedStatement) conn.prepareStatement(sql3);	  
			        rs=pstmt.executeQuery();
		           
					
					if(rs.next()){
					
						System.out.println("该组已存在！");
					}else{
						String groupname="小组"+group.getGroupNumber();
						group.setGroupname(groupname);
						//组现在有名字了
						String sql4="insert into usergroup (groupnum,groupid,groupname,grouppadname) values(?,?,?,?)";
				     
				        pstmt=(PreparedStatement) conn.prepareStatement(sql4);	  
				        
			            
			            pstmt.setString(1,group.getGroupNumber());
			            pstmt.setString(2, group.getGroupID());
			            pstmt.setString(3,group.getGroupname());
			            pstmt.setString(4,group.getPad().getPadName());
			            pstmt.executeUpdate();//向数据库插入小组信息
			           
			            String sql5="insert into pad (padName,padID,padgroupid,padgroupname) values(?,?,?,?)";
			            pstmt=(PreparedStatement) conn.clientPrepareStatement(sql5);
			            pstmt.setString(1,pad.getPadName());
			            pstmt.setString(2,pad.getPadID());
			            pstmt.setString(3,group.getGroupID());
			            pstmt.setString(4,group.getGroupname());
			            pstmt.executeUpdate();//向数据库插入pad信息
			            
					}
					
					
					
					
			        
			        //"http://localhost:9001/api/1/createAuthorIfNotExistsFor?apikey=db5ff753a27998e8e97803b2b0e70288381ad7077965e2336f9bd69c035c7c27&name="+user.getUsername()+"&authorMapper=1"
			       
			    
					
					
					
					
					
					
			        
			    } catch (SQLException e) {
			        e.printStackTrace();
			    }
		
		         System.out.println("*********************End SaveID servlet*********************");   
					
					
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

package eth.bean;

public class Group {

	private String groupID;//创建小组后成功的返回结果，pad和本地数据库都要用到
	private String groupNumber;//小组号码，pad和本地数据库都要用到。
	private String groupname;//小组的名称,本地数据库都要用到
	private Pad pad;//小组的专属pad ，抽象的对象
	

	public Pad getPad() {
		return pad;
	}

	public void setPad(Pad pad) {
		this.pad = pad;
	}

	public String getGroupname() {
		return groupname;
	}

	public void setGroupname(String groupname) {
		this.groupname = groupname;
	}

	public String getGroupNumber() {
		return groupNumber;
	}

	public void setGroupNumber(String groupNumber) {
		this.groupNumber = groupNumber;
	}

	public String getGroupID() {
		return groupID;
	}

	public void setGroupID(String groupID) {
		this.groupID = groupID;
	}

	@Override
	public String toString() {
		return "Group [groupID=" + groupID + ", groupNumber=" + groupNumber + ", groupname=" + groupname + ", pad="
				+ pad + "]";
	}

	


    
	
	

}

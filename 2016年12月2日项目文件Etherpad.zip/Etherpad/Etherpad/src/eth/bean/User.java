package eth.bean;

public class User {
    
	private String authorID;//create author后pad返回的数据 authorID
	private int mapper;//对应本地数据库的用户id pad也要用来创建用户
	private String username;// 用于pad和本地服务器的 用户的 name
	private String password;//仅存于本地数据库
	private Group group;//调用的抽象组对象
	
	public Group getGroup() {
		return group;
	}
	public void setGroup(Group group) {
		this.group = group;
	}
	
	
	
	public int getMapper() {
		return mapper;
	}
	public void setMapper(int mapper) {
		this.mapper = mapper;
	}
	
	
	
	public String getAuthorID() {
		return authorID;
	}
	public void setAuthorID(String authorID) {
		this.authorID = authorID;
	}
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "User [username=" + username + ", password=" + password + ", group=" + group + ", authorID=" + authorID
				+ ", mapper=" + mapper + "]";
	}
  
	
	
	
} 

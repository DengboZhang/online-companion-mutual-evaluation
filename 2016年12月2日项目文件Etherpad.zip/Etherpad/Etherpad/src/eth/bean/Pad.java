package eth.bean;



public class Pad {
	
    private String padName;//pad的name 用于本地和打开pad时的iframe里面嵌入的参数
    private String padID;//小组pad的 独特标识 用于本地和打开pad时的iframe里面嵌入的参数
    
    
    
    
	@Override
	public String toString() {
		return "Pad [padName=" + padName + ", padID=" + padID + "]";
	}
	public String getPadName() {
		return padName;
	}
	public void setPadName(String padName) {
		this.padName = padName;
	}
	public String getPadID() {
		return padID;
	}
	public void setPadID(String padID) {
		this.padID = padID;
	}
    
    
	
	
}

//00:新用户新组
//01:新用户旧组
//10，11提示用户存在的返回信息
var authorID,groupID;
var username,password,groupid,authorMapper,padName;
var apikey,hostinfo;
var bool_usr=false,bool_grp=false,bool_pwd=false;
//apikey="173a36c04238f21138930aa4c21aa2f01e474f08d878592bbb410652794df3a6";
/* hostinfo="http://192.168.137.1:8081/"; 宿舍ip*/
 //hostinfo="http://172.22.102.30:8081/";
function validinfo(obj){
	if(obj.id=="username"&&obj.value!=""){
		bool_usr=true;
	}
	else if(obj.id=="username"&&obj.value==""){
		bool_usr=false;
	}
	else if(obj.id=="groupid"&&obj.value!=""){
		bool_grp=true;
	}
	else if(obj.id=="groupid"&&obj.value==""){
		bool_grp=false;
	}
	else if(obj.id=="password"&&obj.value!=""){
		bool_pwd=true;
	}
	else if(obj.id=="password"&&obj.value==""){
		bool_pwd=false;
	}
	if(bool_pwd&&bool_grp&&bool_usr)
	{
		var regist = document.getElementById("regist");
		var reset = document.getElementById("reset");
		regist.disabled=false;
		reset.disabled=false;
		$(regist).addClass("black");
		$(reset).addClass("yellow");
		$(regist).removeClass("blackdisable");
		$(reset).removeClass("yellowdisable");
	}
	else{
		var regist = document.getElementById("regist");
		var reset = document.getElementById("reset");
		regist.disabled=true;
		reset.disabled=true;
		$(regist).addClass("blackdisable");
		$(reset).addClass("yellowdisable");
		$(regist).removeClass("black");
		$(reset).removeClass("yellow");
	}
}
function postinfo(){
	
	username=document.getElementById("username").value;
	password=document.getElementById("password").value;
	groupid=document.getElementById("groupid").value;
		$.ajax({
			type:"POST",
			dataType:"json",
			url:"DealRegister",//后台判断数据地址
			data:{"username":username,"password":password,"groupid":groupid},//传入后台进行判断的数据
			success:function(result){
				authorMapper=result.authorMapper;
				groupMapper=result.groupMapper;
				padName=result.padName;
				apikey=result.apikey;
				hostinfo=result.hostinfo;
				if(result.data=="00"){//代表人和组都是新创建的
					new Promise(function(resolve,reject){//向服务器发送消息创建新的author
						$.ajax({
							type:"GET",
							jsonp:"jsonp",
							dataType:"jsonp",
							url:hostinfo+"api/1/createAuthorIfNotExistsFor",
							data:{"apikey":apikey,"name":username,"authorMapper":authorMapper},
							success:resolve,
							error:reject
						});
					}).then(function(result){
						authorID=result.data.authorID;//获取服务器放回的authorID
						return new Promise(function(resolve,reject){
							$.ajax({//由于不存在组,所以向服务器发送信息创建组
								type:"GET",
								jsonp:"jsonp",
								dataType:"jsonp",
								url:hostinfo+"api/1/createGroupIfNotExistsFor",
								data:{"apikey":apikey,"groupMapper":groupid},
								success:resolve,
								error:reject
							});
						});
					}).then(function(result){	
						groupID=result.data.groupID;//获取服务器返回的groupID
						return new Promise(function(resolve,reject){
							$.ajax({//向服务器发送请求创建grouppad
								type:"GET",
								jsonp:"jsonp",
								dataType:"jsonp",
								url:hostinfo+"api/1/createGroupPad",
								data:{"apikey":apikey,"groupID":groupID,"padName":padName,"text":"欢迎使用"},
								success:resolve,
								error:reject
							});
						});
					}).then(function(result){
						alert("注册成功"); 
						$.ajax({
							type:"POST",
							dataType:"json",
							url:"SaveID",//后台连接数据库储存信息的地址
							data:{"groupID":groupID,"authorID":authorID,"groupid":groupid},
							success:function(){
								//alert("向后台数据库发送成功");//测试语句
							},
							error:function(){
								//alert("向后台数据库发送失败");//测试语句
							}
						});
						window.location.href='login.jsp'; 
					});
				}
				else if(result.data=="01"){//代表人是新的，组已经存在
					new Promise(function(resolve,reject){//向服务器发送消息创建新的author
						$.ajax({
							type:"GET",
							jsonp:"jsonp",
							dataType:"jsonp",
							url:hostinfo+"api/1/createAuthorIfNotExistsFor",
							data:{"apikey":apikey,"name":username,"authorMapper":authorMapper},
							success:resolve,
							error:reject
						});
					}).then(function(result){
						authorID=result.data.authorID;
						alert("注册成功");
						$.ajax({
							type:"POST",
							dataType:"json",
							url:"SaveID",//后台连接数据库储存信息的地址
							data:{"groupID":null,"authorID":authorID,"groupid":groupid},
							success:function(){
								//alert("向后台数据库发送成功");//测试语句
							},
							error:function(){
								//alert("向后台数据库发送失败");//测试语句
							}
						});
						window.location.href='login.jsp';  
					});
				}
				else{
					alert("用户名已存在，请重新注册")
				}
			},
			error:function(err){
				alert("用户名已存在，请重新注册&或数据错误");
			}
		});
}
function reset(){
	document.getElementById("username").value="";
	document.getElementById("password").value="";
	document.getElementById("groupid").value="";
	var regist = document.getElementById("regist");
	var reset = document.getElementById("reset");
	regist.disabled=true;
	reset.disabled=true;
	$(regist).addClass("blackdisable");
	$(reset).addClass("yellowdisable");
	$(regist).removeClass("black");
	$(reset).removeClass("yellow");
	bool_usr=false;
	bool_grp=false;
	bool_pwd=false;
}

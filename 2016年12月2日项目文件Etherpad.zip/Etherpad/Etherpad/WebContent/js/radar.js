
//1  获取一个画布对象 ，也就是将要产生图标的位置
var ctx = document.getElementById("myChart").getContext("2d");







var data = {
	    labels: ["Eating", "Drinking", "Sleeping", "Designing", "Coding", "Cycling", "Running"],
	    datasets: [
	               
	        {
	            label: "小组一",
	            backgroundColor: "rgba(179,181,198,0.2)",
	            borderColor: "rgba(179,181,198,1)",
	            pointBackgroundColor: "rgba(179,181,198,1)",
	            pointBorderColor: "#fff",
	            pointHoverBackgroundColor: "#fff",
	            pointHoverBorderColor: "rgba(179,181,198,1)",
	            data: [65, 59, 90, 81, 56, 55, 40]
	        },
	        
	        {
	            label: "My Second dataset",
	            backgroundColor: "rgba(255,99,132,0.2)",
	            borderColor: "rgba(255,99,132,1)",
	            pointBackgroundColor: "rgba(255,99,132,1)",
	            pointBorderColor: "#fff",
	            pointHoverBackgroundColor: "#fff",
	            pointHoverBorderColor: "rgba(255,99,132,1)",
	            data: [28, 48, 40, 19, 96, 27, 100]
	        }
	        ,
	     
	        {
	            label: "My third dataset",
	            backgroundColor: "rgba(189,136,200,0.2)",
	            borderColor: "rgba(166,135,140,1)",
	            pointBackgroundColor: "rgba(173,161,158,1)",
	            pointBorderColor: "#fff",
	            pointHoverBackgroundColor: "#fff",
	            pointHoverBorderColor: "rgba(165,131,158,1)",
	            data: [68, 49, 68, 47, 39, 57, 39]
	        }
	    
	]};

var myRadarChart = new Chart(ctx, {
    type: 'radar',
    data: data,
    options: options
});


var options={
    scale: {
        reverse: false,
        ticks: {
            beginAtZero: false
        },
        type:'radialLinear'
    } 
  
    
}




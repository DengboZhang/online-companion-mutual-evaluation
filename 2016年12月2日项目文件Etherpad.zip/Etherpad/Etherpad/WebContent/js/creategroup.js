var apikey, url;
			apikey = "db5ff753a27998e8e97803b2b0e70288381ad7077965e2336f9bd69c035c7c27";
			function callback(result) {
				var obj = JSON.stringify(result);
				var obj = eval("(" + obj + ")");
				document.getElementById("groupID").value = obj.data.groupID;
			}
			function postinfo() {
	
				$.ajax({
							type : "GET",
							dataType : "jsonp",
							url : "http://localhost:9001/api/1/createGroupIfNotExistsFor?jsonp=callback",
							data : {
								"apikey" : apikey,
								"groupMapper" : "1"
							},//groupmapper让它等于上面的groupnumber 
						});
			}